//
//  Focus.swift
//  GBoardApp
//
//  Created by Dev2 on 29/05/2019.
//  Copyright © 2019 Dev2. All rights reserved.
//

import Foundation

enum FocusType  {
    case financial
    case customer
    case process
    case growth
}
